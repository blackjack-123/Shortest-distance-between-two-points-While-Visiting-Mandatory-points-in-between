﻿1. Open the code.cpp file in your local computers vs code. 
2. Then execute the code to see the results.